// .stop()은 이전 동작을 멈추고 다음 액션-.animate() .slideDown() .slideUp() .show() .hide()등-을 실행하라는 의미로 생략가능.

$(".menu > ul > li").hover
    (function () {
        // over
        $(this).children("ul").stop().slideDown("slow");

    }, function () {
        // out
        $(this).children("ul").stop().slideUp("fast");
    }
    );