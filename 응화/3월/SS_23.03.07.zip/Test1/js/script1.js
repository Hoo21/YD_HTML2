//.stop()는 이전 동작을 멈추고 다음 액션-.animate() .slideDown() .slideUp() .show() .hide()등-을 실행하라는 의미로 생략가능 

$(".menu").hover(function () {
        // over
        $(".sub-menu").slideDown("slow");
    }, function () {
        // out
        $(".sub-menu").slideUp("fast");
    }
);