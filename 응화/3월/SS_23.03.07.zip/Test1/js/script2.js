$(".menu").hover(function () {
    // over
    $(".sub-menu").slideDown("slow");
}, function () {
    // out
    $(".sub-menu").slideUp("fast");
}
);