$(".menu ul li").hover(function () {
        // over
        $(this).children("ul").stop().slideDown("slow");
        
    }, function () {
        // out
        $(this).children("ul").stop().slideUp("fast");
    }
);