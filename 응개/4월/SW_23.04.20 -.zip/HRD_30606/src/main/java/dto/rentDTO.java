package dto;

public class rentDTO {
	private int custno;
	private int bookno;
	private String rentdate;
	private String returndate;
	
	public rentDTO() {
		// TODO Auto-generated constructor stub
	}

	public rentDTO(int custno, int bookno, String rentdate, String returndate) {
		super();
		this.custno = custno;
		this.bookno = bookno;
		this.rentdate = rentdate;
		this.returndate = returndate;
	}

	public int getCustno() {
		return custno;
	}

	public void setCustno(int custno) {
		this.custno = custno;
	}

	public int getBookno() {
		return bookno;
	}

	public void setBookno(int bookno) {
		this.bookno = bookno;
	}

	public String getRentdate() {
		return rentdate;
	}

	public void setRentdate(String rentdate) {
		this.rentdate = rentdate;
	}

	public String getReturndate() {
		return returndate;
	}

	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}
	
	
}
