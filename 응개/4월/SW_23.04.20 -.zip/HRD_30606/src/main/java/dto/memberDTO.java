package dto;

public class memberDTO {
	private int custno;
	private String custname;
	private String joindate;
	private String grade;
	private String address;
	
	public memberDTO() {
		// TODO Auto-generated constructor stub
	}

	public memberDTO(int custno, String custname, String joindate, String grade, String address) {
		super();
		this.custno = custno;
		this.custname = custname;
		this.joindate = joindate;
		this.grade = grade;
		this.address = address;
	}

	public int getCustno() {
		return custno;
	}

	public void setCustno(int custno) {
		this.custno = custno;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getJoindate() {
		return joindate;
	}

	public void setJoindate(String joindate) {
		this.joindate = joindate;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
