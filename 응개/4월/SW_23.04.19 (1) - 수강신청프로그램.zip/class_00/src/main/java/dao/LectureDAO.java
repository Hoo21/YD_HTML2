package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.LectureDTO;
import dto.LecturerDTO;
import util.JDBCUtil;

public class LectureDAO {
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	final String SELECT_LECTURE_ALL = "SELECT a.id, a.name major, a.credit, b.name, a.week, a.start_hour, a.end_end "
			+ "FROM course_tbl a, lecturer_tbl b "
			+ "WHERE a.lecturer = b.idx "
			+ "ORDER BY a.id desc";
	final String SELECT_LECTURER_ALL = "SELECT * FROM lecturer_tbl";
	final String INSERT_LECTURE = "INSERT INTO course_tbl VALUES(?,?,?,?,?,?,?)";
	final String SELECT_LECTURE = "SELECT * FROM course_tbl WHERE id=?";
	final String UPDATE_LECTURE = "UPDATE course_tbl SET id=?, name=?, credit=?, lecturer=?, "
			+ "week=?, start_hour=?, end_end=? WHERE id=?";
	final String DELETE_LECTURE = "DELETE FROM course_tbl WHERE id=?";
	
	
	public ArrayList<LectureDTO> selectLecture() {
		ArrayList<LectureDTO> list = new ArrayList<>();
		
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareStatement(SELECT_LECTURE_ALL);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				LectureDTO dto = new LectureDTO(
					rs.getString("id"),
					rs.getString("major"),
					rs.getInt("credit"),
					rs.getString("name"),
					rs.getInt("week"),
					rs.getInt("start_hour"),
					rs.getInt("end_end")
				 );
				list.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}
	
	
	public ArrayList<LecturerDTO> selectLecturer() {
		ArrayList<LecturerDTO> list = new ArrayList<>();
		
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareCall(SELECT_LECTURER_ALL);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				LecturerDTO dto = new LecturerDTO(
					rs.getInt("idx"),
					rs.getString("name"),
					rs.getString("major"),
					rs.getString("field")
				 );
				list.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	public int insertLecture(LectureDTO dto) {
		int cnt = 0;
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareStatement(INSERT_LECTURE);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getName());
			pstmt.setInt(3, dto.getCredit());
			pstmt.setString(4, dto.getLecturer());
			pstmt.setInt(5, dto.getWeek());
			pstmt.setInt(6, dto.getStartHour());
			pstmt.setInt(7, dto.getEndHour());
			cnt = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	public LectureDTO selectOneLecture(String id) {
		LectureDTO dto = null;
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareStatement(SELECT_LECTURE);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new LectureDTO(
					rs.getString("id"),
					rs.getString("name"),
					rs.getInt("credit"),
					rs.getString("lecturer"),
					rs.getInt("week"),
					rs.getInt("start_hour"),
					rs.getInt("end_end")
				 );
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto;
		
	}
	
	
	public int updateLecture(LectureDTO dto, int num) {
		int cnt = 0;
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareStatement(UPDATE_LECTURE);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getName());
			pstmt.setInt(3, dto.getCredit());
			pstmt.setString(4, dto.getLecturer());
			pstmt.setInt(5, dto.getWeek());
			pstmt.setInt(6, dto.getStartHour());
			pstmt.setInt(7, dto.getEndHour());
			pstmt.setInt(8, num);
			cnt = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	
	public int deleteLecture(int id) {
		int cnt = 0;
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareStatement(DELETE_LECTURE);
			pstmt.setInt(1, id);
			cnt = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
