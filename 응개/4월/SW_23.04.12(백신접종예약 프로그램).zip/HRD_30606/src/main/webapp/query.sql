create table tbl_jumin_202108(
	jumin char(14) primary key,
	pname varchar2(16),
	tel varchar2(13),
	address varchar2(10)
);

select * from tbl_jumin_202108;

insert into tbl_jumin_202108 values('710101-1000001','김주민','010-1234-0001','서울');
insert into tbl_jumin_202108 values('720101-2000002','이주민','010-1234-0002','서울');
insert into tbl_jumin_202108 values('730101-1000003','박주민','010-1234-0003','서울');
insert into tbl_jumin_202108 values('740101-2000004','조주민','010-1234-0004','대전');
insert into tbl_jumin_202108 values('750101-1000005','홍주민','010-1234-0005','대전');
insert into tbl_jumin_202108 values('760101-2000006','나주민','010-1234-0006','대구');
insert into tbl_jumin_202108 values('770101-1000007','황주민','010-1234-0007','대구');
insert into tbl_jumin_202108 values('780101-2000008','용주민','010-1234-0008','광주');
insert into tbl_jumin_202108 values('790101-1000009','백주민','010-1234-0009','광주');
insert into tbl_jumin_202108 values('800101-2000010','송주민','010-1234-0010','광주');

create table tbl_hosp_202108(
	hospcode char(4) primary key,
	hospname varchar2(10),
	hosptel varchar2(10),
	hospaddr varchar2(10)
);

select * from tbl_hosp_202108;

select hospcode, hospname from tbl_hosp_202108;

insert into tbl_hosp_202108 values('H001', '가-병원', '1588-0001', '서울');
insert into tbl_hosp_202108 values('H002', '나-병원', '1588-0002', '대전');
insert into tbl_hosp_202108 values('H003', '다-병원', '1588-0003', '대구');
insert into tbl_hosp_202108 values('H004', '라-병원', '1588-0004', '광주');

create table tbl_vaccresv_202108(
	resvno char(8) primary key,
	jumin char(14),
	vcode char(4),
	hospcode char(4),
	resvdate char(8),
	resvyime char(4)
);

drop table tbl_vaccresv_202108;

select * from tbl_vaccresv_202108;

insert into tbl_vaccresv_202108 values('20210001','710101-1000001','V001','H001','20210901','0921');
insert into tbl_vaccresv_202108 values('20210002','720101-2000002','V001','H002','20210901','1030');
insert into tbl_vaccresv_202108 values('20210003','730101-1000003','V002','H003','20210902','1130');
insert into tbl_vaccresv_202108 values('20210004','740101-2000004','V002','H001','20210902','1230');
insert into tbl_vaccresv_202108 values('20210005','750101-1000005','V002','H002','20210902','1330');
insert into tbl_vaccresv_202108 values('20210006','760101-2000006','V003','H003','20210903','1430');
insert into tbl_vaccresv_202108 values('20210007','770101-1000007','V003','H001','20210903','1530');
insert into tbl_vaccresv_202108 values('20210008','780101-2000008','V003','H002','20210903','1630');
insert into tbl_vaccresv_202108 values('20210009','790101-1000009','V003','H003','20210904','1730');
insert into tbl_vaccresv_202108 values('20210010','800101-2000010','V003','H001','20210904','1830');

select h.hospname, count(h.hospcode) count
from tbl_hosp_202108 h, tbl_vaccresv_202108 v
where h.hospcode = v.hospcode
group by h.hospname
order by h.hospname asc;

select sum(count(h.hospcode)) total
from tbl_hosp_202108 h, tbl_vaccresv_202108 v
where h.hospcode = v.hospcode
group by h.hospcode;

select j.pname, j.jumin, j.tel, v.resvdate, v.resvyime, h.hospname, h.hosptel, h.hospaddr, v.vcode
from TBL_JUMIN_202108 j, TBL_HOSP_202108 h, tbl_vaccresv_202108 v
where (h.hospcode = v.hospcode and j.jumin = v.jumin) and v.resvno='20210001';
