package dto;

public class ResvDTO {
	private String jumin;
	private String pname;
	private String tel;
	private String address;
	
	public ResvDTO() {
		// TODO Auto-generated constructor stub
	}

	public ResvDTO(String jumin, String pname, String tel, String address) {
		super();
		this.jumin = jumin;
		this.pname = pname;
		this.tel = tel;
		this.address = address;
	}

	public String getJumin() {
		return jumin;
	}

	public void setJumin(String jumin) {
		this.jumin = jumin;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
