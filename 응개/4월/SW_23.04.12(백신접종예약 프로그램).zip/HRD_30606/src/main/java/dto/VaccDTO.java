package dto;

public class VaccDTO {
	private String resvno;
	private String jumin;
	private String vscode;
	private String hospcode;
	private String resvdate;
	private String resvyime;
	
	public VaccDTO() {
		// TODO Auto-generated constructor stub
	}

	public VaccDTO(String resvno, String jumin, String vscode, String hospcode, String resvdate, String resvyime) {
		super();
		this.resvno = resvno;
		this.jumin = jumin;
		this.vscode = vscode;
		this.hospcode = hospcode;
		this.resvdate = resvdate;
		this.resvyime = resvyime;
	}

	public String getResvno() {
		return resvno;
	}

	public void setResvno(String resvno) {
		this.resvno = resvno;
	}

	public String getJumin() {
		return jumin;
	}

	public void setJumin(String jumin) {
		this.jumin = jumin;
	}

	public String getVscode() {
		return vscode;
	}

	public void setVscode(String vscode) {
		this.vscode = vscode;
	}

	public String getHospcode() {
		return hospcode;
	}

	public void setHospcode(String hospcode) {
		this.hospcode = hospcode;
	}

	public String getResvdate() {
		return resvdate;
	}

	public void setResvdate(String resvdate) {
		this.resvdate = resvdate;
	}

	public String getResvyime() {
		return resvyime;
	}

	public void setResvyime(String resvyime) {
		this.resvyime = resvyime;
	}
	
	
	
}
