package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import Util.JDBCUtil;
import dto.HospDTO;
import dto.VaccDTO;

public class ResvDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	final String INSERT_VACC = "INSERT INTO tbl_vaccresv_202108 values(?,?,?,?,?,?)";
	final String SELECT_HOSP = "SELECT * FROM tbl_hosp_202108";

	public int insertVacc(VaccDTO dto) {
		int cnt = 0;
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareStatement(INSERT_VACC);
			pstmt.setString(1, dto.getResvno());
			pstmt.setString(2, dto.getJumin());
			pstmt.setString(3, dto.getVscode());
			pstmt.setString(4, dto.getHospcode());
			pstmt.setString(5, dto.getResvdate());

			pstmt.setString(6, dto.getResvyime());
			cnt = pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;

	}

	public int selectVacc(VaccDTO dto) {
		int cnt = 0;
		try {
			conn = JDBCUtil.getConn();
			pstmt = conn.prepareStatement(INSERT_VACC);
			pstmt.setString(1, dto.getResvno());
			pstmt.setString(2, dto.getJumin());
			pstmt.setString(3, dto.getVscode());
			pstmt.setString(4, dto.getHospcode());
			pstmt.setString(5, dto.getResvdate());

			pstmt.setString(6, dto.getResvyime());
			cnt = pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;

	}

	public ArrayList<HospDTO> selecthosp() {
			ArrayList<HospDTO> list = new ArrayList<>();
			try {
				conn = JDBCUtil.getConn();
				pstmt = conn.prepareStatement(SELECT_HOSP);
				rs= pstmt.executeQuery();
				
				while (rs.next()) {
					HospDTO dto = new HospDTO(
					rs.getString("hostpcode");
					rs.getString("hospname");
					rs.getInt("total");
					);
					list.add(dto);
					
				}
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			} return list;
		}

}
