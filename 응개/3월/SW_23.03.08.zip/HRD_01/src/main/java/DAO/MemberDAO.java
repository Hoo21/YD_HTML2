package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import DTO.MemberDTO;
import Util.JDBCUtil;

public class MemberDAO {
	// DB
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	// Query
	final String INSERT_MEMEBER = "INSERT INTO member_tbl_02 values(?,?,?,?,?,?,?)";
	final String FIND_MAX_CUSTNO = "SELECT max(custno) FROM member_tbl_02";
	final String SELECT_MEMBER_ALL = "SELECT * FROM member_tbl_02";
	
	

	// 회원번호 자동생성
	public int maxCustno() {
		int max = 0;
		try {
			con = JDBCUtil.getConnection();
			pstmt = con.prepareStatement(FIND_MAX_CUSTNO);
			rs = pstmt.executeQuery();

			// 값 꺼내오기, 확인
			if (rs.next()) {
				max = rs.getInt(1);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return max;

	}

	// Insert
	public int register(MemberDTO dto) {
		// JDBC Connection
		int cnt = 0;
		try {
			con = JDBCUtil.getConnection();
			// String sql = "INSERT INTO member_tbl_02 values(?,?,?,?,?,?,?)";

			pstmt = con.prepareStatement(INSERT_MEMEBER);
			pstmt.setInt(1, dto.getCustno());
			pstmt.setString(2, dto.getCustname());
			pstmt.setString(3, dto.getPhone());
			pstmt.setString(4, dto.getAddress());
			pstmt.setDate(5, dto.getJoindate());
			pstmt.setString(6, dto.getGrade());
			pstmt.setString(7, dto.getCity());

			// select만 pstmt.executeQuery(). insert: pstmt.executeUpdate();
			cnt = pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;

	}

	// Select
	public ArrayList<MemberDTO> selectMembers() {
			ArrayList<MemberDTO> list = null;
			// getConnection
			try {
				con = JDBCUtil.getConnection();
				
				// SELECT Query
				// pstmt
				pstmt = con.prepareStatement(SELECT_MEMBER_ALL);
				
				// rs
				rs =  pstmt.executeQuery();
				
				// rs.next
				while(rs.next()) {
					// rs.get
					int custno = rs.getInt("custno");
					String custname = rs.getString("custname");
					String phone = rs.getString("phone");
					String address = rs.getString("address");
					Date joindate = rs.getDate("joindate");
					String grade = rs.getString("grade");
					String city = rs.getString("city");
					
					// ArrayList add DTO type
					MemberDTO dto = new MemberDTO(custno, custname, phone, address, joindate, grade, city);
					list.add(dto);
					
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			// return arrayList
			return list;
		}

}
