export class Keyboard {
    #switchEl
    #fontSelectEl
    #containerEl
    #keyboardEl

    constructor() {
        this.#assignElement()
        this.#addEvent()

    }

    //초기화
    #assignElement() {
        //this.#switchEl = document.getElementById(`switch`)
        this.#containerEl = document.getElementById('container')
        this.#switchEl = this.#containerEl.querySelector(`#switch`)
        this.#fontSelectEl = this.#containerEl.querySelector(`#font`)

        // container 안에 있는 키보드 바로찾기 >> query select
        this.#keyboardEl = this.#containerEl.querySelector('#keyboard')
    }

    //CSS 다크모드
    #addEvent() {
            this.#switchEl.addEventListener('change', this.#onChangeTheme)
            this.#fontSelectEl.addEventListener('change', this.#onChangeFont)
            document.addEventListener('keydown', (e) => {
                //console.log(e.key)
                // ? : null이 아니면 실행, null 값이면 실행X
                // 옵셔널 체이닝 문법 ex.dart문법
                
                this.#keyboardEl.querySelector(`[data-code=${e.code}]`)?.classList.add('active')
            })
            document.addEventListener('keyup', (e) => {
                this.#keyboardEl.querySelector(`[data-code=${e.code}]`)?.classList.remove('active')
            })
        }

    
    

    #onChangeTheme(e) {
        document.documentElement.setAttribute(
            'theme',
            e.target.checked ? 'dark-mode' : ''
        )
    }

    #onChangeFont(e) {
        document.body.style.fontFamily = e.target.value
    }
}