import "../css/style.css"
// console.log("hi")
import { Keyboard } from "./keyboard"
new Keyboard()