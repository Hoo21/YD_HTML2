export class Keyboard {
    #switchEl
    #fontSelectEl
    #containerEl
    #keyboardEl
    #inputGroupEl
    #inputEl
    #keyPress = false
    #mouseDown = false

    constructor() {
        this.#assignElement()
        this.#addEvent()

    }

    //초기화
    #assignElement() {
        //this.#switchEl = document.getElementById(`switch`)
        this.#containerEl = document.getElementById('container')
        this.#switchEl = this.#containerEl.querySelector(`#switch`)
        this.#fontSelectEl = this.#containerEl.querySelector(`#font`)

        // container 안에 있는 키보드 바로찾기 >> query select
        this.#keyboardEl = this.#containerEl.querySelector('#keyboard')
        this.#inputGroupEl = this.#containerEl.querySelector('#input-group')
        this.#inputEl = this.#inputGroupEl.querySelector('#input')
    }

    //CSS 다크모드
    #addEvent() {
            this.#inputEl.addEventListener('input', (e) => {
                e.target.value = e.target.value.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/ ,'')
            })
            this.#switchEl.addEventListener('change', this.#onChangeTheme)
            this.#fontSelectEl.addEventListener('change', this.#onChangeFont)
            this.#keyboardEl.addEventListener('mousedown', (e) => {
                if(this.#keyPress) return
                this.#mouseDown = true
                e.target.closest('div.key')?.classList.add('active')
            })

            this.#keyboardEl.addEventListener('mouseup', (e) => {
                //e.target.closest('div.key')?.classList.remove('active')
                // 키보드 상태 체크, 눌려있는지 아닌지
                if(this.#keyPress) return
                this.#mouseDown = false
                
                const keyEl = e.target.closest('div.key')
                // undefined 는 isActive가 false 로 처리되게
                //const isActive = !keyEl?.classList.contains('active')
                const isActive = !!keyEl?.classList.contains('active')
                const val = keyEl?.dataset.val
                
                if(isActive && !!val && val !== 'Space' && val != 'Backspace') {
                    this.#inputEl.value += val
                }
                if(isActive && val === 'Space'){
                    this.#inputEl.value += ' '
                }
                if(isActive && val === 'Backspace') {
                    this.#inputEl.value = this.#inputEl.value.slice(0,-1)
                }

                this.#keyboardEl.querySelector('.active')?.classList.remove('active')
            })

            document.addEventListener('keydown', (e) => {
                //console.log(e.key)
                // ? : null이 아니면 실행, null 값이면 실행X
                // 옵셔널 체이닝 문법 ex.dart문법
                if(this.#mouseDown) return
                this.#keyPress = true
                
                this.#inputGroupEl.classList.toggle(
                    'error',
                    e.key==='Process'
                )
                this.#keyboardEl.querySelector(`[data-code=${e.code}]`)?.classList.add('active')
            })
            document.addEventListener('keyup', (e) => {
                if(this.#mouseDown) return
                this.#keyPress = false
                this.#keyboardEl.querySelector(`[data-code=${e.code}]`)?.classList.remove('active')
            })
        }

    
    

    #onChangeTheme(e) {
        document.documentElement.setAttribute(
            'theme',
            e.target.checked ? 'dark-mode' : ''
        )
    }

    #onChangeFont(e) {
        document.body.style.fontFamily = e.target.value
    }
}