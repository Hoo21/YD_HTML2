import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var _addValue = 0 as double;  //변수선언
  //double _addValue = 0.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Basic List"),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(
                value: _addValue, //진행정도
                backgroundColor: Colors.yellow, //진행X
                color: Colors.brown,  //진행O
                strokeWidth: 10,  //바 굵기

              ),
              SizedBox(height: 30,),
              LinearProgressIndicator(
                value: _addValue,
                backgroundColor: Colors.green,
                color: Colors.black,
                minHeight: 10,   //바 굵기(CircularProgressIndicator와 다름)

              ),
              ElevatedButton(onPressed: (){
                setState(() {
                  _addValue += 0.1;
                  if(_addValue >= 1.0)
                    _addValue = 0.0;
                });

              }, child: Text("증가"))
            ],
          ),
        ));
  }
}
