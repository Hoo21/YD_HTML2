import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var _animalName;
  var _imageName;
  int _radioValue = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Animal'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: '동물 애칭을 입력하세요.',
                ),
                onChanged: (text) {
                  _imageName = text;
                  //print(_imageName);
                },
              ),
              SizedBox(
                height: 20,
              ),
              RadioListTile(
                title: Text('양서류'),
                value: 0,
                groupValue: _radioValue,
                onChanged: _radioChange,
              ),
              RadioListTile(
                title: Text('파충류'),
                value: 1,
                groupValue: _radioValue,
                onChanged: _radioChange,
              ),
              RadioListTile(
                title: Text('포유류'),
                value: 2,
                groupValue: _radioValue,
                onChanged: _radioChange,
              ),
              SizedBox(
                height: 20,
              ),

              // Container(
              //  height: 100,
              //  child: ListView(
              //        scrollDirection: Axis.horizontal,
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    GestureDetector(
                      child: Image.asset(
                        'assets/cow.png',
                        height: 90,
                        width: 90,
                      ),
                      onTap: () {
                        _animalName = 'cow';
                      },
                    ),
                    GestureDetector(
                        child: Image.asset(
                          'assets/pig.png',
                          height: 90,
                          width: 90,
                        ),
                        onTap: () {
                          _animalName = 'pig';
                        }),
                    GestureDetector(
                        child: Image.asset(
                          'assets/dog.png',
                          height: 90,
                          width: 90,
                        ),
                        onTap: () {
                          _animalName = 'dog';
                        }),
                    GestureDetector(
                        child: Image.asset(
                          'assets/bee.png',
                          height: 90,
                          width: 90,
                        ),
                        onTap: () {
                          _animalName = 'bee';
                        }),
                    GestureDetector(
                        child: Image.asset(
                          'assets/fox.png',
                          height: 90,
                          width: 90,
                        ),
                        onTap: () {
                          _animalName = 'fox';
                        }),

                  ],
                ),
              ),
              ElevatedButton(
                  onPressed: () {
                    showDialog(
                        context: context,
                        //barrierDismissible: false,
                        builder: (context) {
                          return AlertDialog(
                            content: Text(
                              '이 동물은 ${_animalName}, 이름은 ${_imageName} 입니다. 동물의 종류는 ${getKind(_radioValue)}입니다.\n 이 동물을 추가하시겠습니까?',
                              style: TextStyle(fontSize: 20.0),
                            ),
                            actions: [
                              ElevatedButton(
                                onPressed:(){
                                  Navigator.of(context).pop();
                                },
                                child: Text('예'),
                              ),
                            ],
                          );
                        }
                    );
                  },
                  child: Text('동물 추가하기')
              ),
            ],
          ),
        ),
      ),
    );
  }

  _radioChange(int? value) {
    //_radioChange(ANIMAL? value) {
    setState(() {
      _radioValue = value as int;
      //_aniVal = value as ANIMAL;
    });
  }

  getKind(int radioValue) {
    switch (radioValue) {
      case 0:
        return "양서류";
      case 1:
        return "파충류";
      case 2:
        return "포유류";
    }
  }
}
