import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        leading: Icon(
          Icons.arrow_back_ios,
          color: Colors.black,
        ),
        actions: [
          Icon(
            Icons.search,
            color: Colors.black,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.asset(
              './assets/moraine.jpg',
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              "Moraine lake",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            Text(
              "Alberta, Canada",
              style: TextStyle(fontSize: 20, color: Colors.grey),
            ),
            SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Icon(Icons.call),
                    Text(
                      "CALL",
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
                SizedBox(
                  width: 60,
                ),
                Column(
                  children: [
                    Icon(Icons.navigation),
                    Text(
                      "ROUTE",
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
                SizedBox(
                  width: 60,
                ),
                Column(
                  children: [
                    Icon(Icons.share),
                    Text(
                      "SHARE",
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(
                    "The waters of Moraine Lake seem like they have been poured straight from the heavens into"
                    'the Valley of the Ten Peaks. The towering mountains encircle the deep blue surface of the lake'
                    'in a formation so extraordinary, only Mother Nature could shape it.'
                    'Piles of boulders have been seemingly dropped by the hands of giants, forming miniature'
                    'mountains near the lakeshore. Let yourself be drawn to the trails that wind amongst the rocks and'
                    "travel beyond to alpine meadows and sparkling lakes",
                    style: TextStyle(fontSize: 17),
                    textAlign: TextAlign.left,
                  ),
                ),
                SizedBox(height: 20,),
                ElevatedButton(onPressed: null, child: Icon(Icons.print)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
