import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

//버튼
class _MyHomePageState extends State<MyHomePage> {
  int count = 0;
  late Timer _timer; //변수 선언

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('flutter demo'),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text(
            '$count',
          ),

          // 누를 때 이후 1초마다 1씩 증가하게
          onPressed: () {
            _timer = Timer.periodic(Duration(seconds: 1), (timer) {
              setState(() {
                count++;
              });
            });
          },

          /*
          //카운트
          // Timer 클래스 /  반복주기 , 실행함수
          // Timer.periodic( Duration(seconds: 30), (timer) {} )

          onPressed: () {
            setState(() {
              count++;
            });
          },

           */
        ),
      ),
    );
  }
}
