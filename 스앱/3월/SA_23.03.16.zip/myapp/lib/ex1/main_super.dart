class Parent {int x =10;}

class Child extends Parent{
    int x=20;
    void method() {
      print("x = $x");
      print("this.x = ${this.x}");
      print("super.x = ${super.x}");

    }

}
main() {
  Child c= Child();
  c.method();
}