class Car {
  num? price;
  int? maxSpeed;
  String? name;


  Car({this.price, this.maxSpeed, this.name});

  num? saleCar(){
    price = (price??0) * 0.9;
    return price;
  }

}

main() {
Car bmw= Car(maxSpeed:320, price:100000, name: 'BMW');
Car benz = Car(maxSpeed:250, price: 70000, name: 'BENZ');
Car ford = Car(maxSpeed:200, price: 80000, name: 'FORD');

  bmw.saleCar();
  benz.saleCar();

  print(bmw.price);
  print(benz.price);
}

