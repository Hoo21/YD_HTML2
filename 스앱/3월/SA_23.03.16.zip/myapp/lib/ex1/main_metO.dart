class Parent{
  void test() {
    print("부모 클래스의 Print()");
  }
}

class Child extends Parent{
  void test() {
    print("자식 클래스의 Print()");
  }
}

main() {
  Parent p1 = Parent();
  p1.test();

  Child c1 = Child();
  c1.test();
}