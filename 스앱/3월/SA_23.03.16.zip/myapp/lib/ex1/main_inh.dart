class Point {
  int x = 1, y = 2;
}

class Point3D extends Point {
  int z = 3;
}

main() {
  Point3D p = new Point3D();
  print('x= ${p.x} y=${p.y} z=${p.z}');
}