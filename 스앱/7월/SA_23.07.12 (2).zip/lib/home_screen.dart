import 'package:flutter/material.dart';
import 'poster.dart';
import 'play_button.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    Size appSize = MediaQuery.of(context).size; // 현재 기기의 화면 크기 저장
    List<String> posters = [
      "assets/big_buck_bunny_poster.jpg",
      "assets/les_miserables_poster.jpg",
      "assets/minari_poster.jpg",
      "assets/the_book_of_fish_poster.jpg",
    ];

    return Scaffold(
      body: Stack(
        children: [
          Image(
            image: AssetImage(posters[0]),
            height: appSize.height, //Image 위젯 틀 세로
            width: double.infinity, // 위젯 틀 가로, appSize, Width 도 가능
            fit: BoxFit.fill, // 이미지 채움 설정
          ),
          Container(
            height: appSize.height,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                //배경 그라데이션 적용
                begin: Alignment.topCenter, //위에서 아래
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.2),
                  Colors.black.withOpacity(0.0),
                  Colors.black,
                ],
                stops: [0.0, 0.5, 0.9], // 각 색상에 대해 하나의 종료점을 추가
              ),
            ),
          ),
          CustomScrollView(
            slivers: [
              SliverAppBar(
                backgroundColor: Colors.transparent,
                leading: Center(
                  child: Text(
                    "M",
                    style: TextStyle(
                        fontSize: 26.0,
                        color: Colors.red,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                actions: [
                  Icon(Icons.search),
                  SizedBox(width: 25.0),
                ],
              ),
              SliverAppBar(
                textTheme: TextTheme(headline6: TextStyle(fontSize: 18.0)),
                automaticallyImplyLeading: false,
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                pinned: true, // 스크롤 시 앱바가 위로 올라가지 않도록 고정, => 두번째 앱바는 고정
                centerTitle: true,
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Text(
                      "TV 프로그램",
                    ),
                    Text(
                      "영화",
                    ),
                    Text(
                      "내가 찜한 콘텐츠",
                    ),
                  ],
                ),
              ),
              SliverToBoxAdapter(
                child: GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: () {
                    showModalBottomSheet(
                      context: context,
                      builder: _buildInfoBottomSheet,
                    );
                  },
                  child: Container(
                    height: (appSize.height * 0.6),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          "오늘 한국에서 콘텐츠 순위 1위",
                          style:
                              TextStyle(fontSize: 16.0, color: Colors.yellow),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                Icon(
                                  Icons.add,
                                  color: Colors.white,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "내가 찜한 콘텐츠",
                                  style: TextStyle(fontSize: 12),
                                ),
                              ],
                            ),
                            PlayButton(
                              width: 80,
                            ),
                            Column(
                              children: [
                                Icon(
                                  Icons.info_outline,
                                  color: Colors.white,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "정보",
                                  style: TextStyle(fontSize: 12),
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 30,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.only(bottom: 30, left: 10),
                sliver: SliverToBoxAdapter(
                  child: Container(
                    height: 200,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "TV",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              TextSpan(text: "프로그램 로맨스"),
                            ],
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Expanded(
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: List.generate(
                              posters.length,
                              (index) => Poster(
                                posterUrl: posters[index],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 함수
  Widget _buildInfoBottomSheet(BuildContext context) {
    return Wrap(
      //공간 부족 시 자동 줄바꿈
      children: [
        Stack(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color(0xFF2B2B2B),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: Image(
                            image: AssetImage(
                              "assets/big_buck_bunny_poster.jpg",
                            ),
                            width: 100.0,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "빅 벅 버니",
                                style: TextStyle(fontSize: 18),
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              Text(
                                "버니가 좋아하는 나비들 중 2마리가 죽고 "
                                "버니 자신에게 공격이 오자 "
                                "버니는 온순한 자연을 뒤로하고 "
                                "2마리의 나비로 인해 복수할 계획들을 치밀히 세운다.",
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        PlayButton(
                          width: 160,
                        ),
                        Column(
                          children: [
                            Icon(
                              Icons.download,
                              color: Colors.white,
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                              "저장",
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Icon(
                              Icons.play_circle_outline,
                              color: Colors.white,
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                              "미리보기",
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              //위치지정
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context); // 이전 화면으로 돌아가기
                },
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: Color(0xFF525252),
                  ),
                  child: Icon(
                    Icons.clear,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
