import 'package:flutter/material.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';
import 'episode.dart';

class ComingScreen extends StatefulWidget {
  ComingScreen({Key? key}) : super(key: key);

  @override
  State<ComingScreen> createState() => _ComingScreenState();
}

class _ComingScreenState extends State<ComingScreen> {
  late VideoPlayerController _videoPlayerController;
  ChewieController? _chewieController;

  Future<void> initializePlayer() async {
    // VideoPlayerController를 저장하기 위한 변수를 만듭니다. VideoPlayerController는
    // asset, 파일, 인터넷 등의 영상들을 제어하기 위해 다양한 생성자를 제공합니다.
    _videoPlayerController = VideoPlayerController.networkUrl(
        Uri.parse('https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4'));
        //Uri.parse('https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4'));
    await Future.wait([_videoPlayerController.initialize()]); // 데이터 소스 열고 초기화
    _chewieController = ChewieController(                  // 비디오 재생(UI 기능 지원)을 위해 선언
      videoPlayerController: _videoPlayerController,
      autoPlay: true,
    );
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    initializePlayer();
  }

  @override
  void dispose() {    //자원 해지
    _videoPlayerController.dispose();
    _chewieController?.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
         // backgroundColor: Colors.trans,
          title: Text("공개예정",style: TextStyle(fontSize: 18),),
          actions: [
            Icon(Icons.search),
            SizedBox(
              width: 30,
            )
          ],
        ),
      body: Column(
        children: [
          Container(
            height: 230,
            child: _chewieController != null &&
                _chewieController!.videoPlayerController.value.isInitialized
                ? Chewie(controller: _chewieController!)     // 초기화가 정상적이면  실행
                : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                CircularProgressIndicator(),                 //초기화 진행중이면 기다리기
                SizedBox(height: 20),
                Text('Loading'),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Row(
                    children: [
                      Text(
                        " Big Buck Bunny",
                        style: TextStyle(fontSize: 25.0,color: Colors.white),
                      ),
                      SizedBox(width: 30,),
                      Column(
                        children: [
                          Icon(Icons.add_alert_outlined, color: Colors.white,),
                          //SizedBox(height: 5.0),
                          Text(
                            "알림받기",
                            style: TextStyle(fontSize: 12.0),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    "7월 10일 공개",
                    style: TextStyle(fontSize: 16.0),
                  ),
                  Text(
                    " 빅 벅 버니",
                    style: TextStyle(fontSize: 18.0, color: Colors.white),
                  ),
                  SizedBox(height: 10.0),
                  Text(episodes[0].description),
                ],
              ),
            ),
          ),
        ],
      )
    );
  }
}
