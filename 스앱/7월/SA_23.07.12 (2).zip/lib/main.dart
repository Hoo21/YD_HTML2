import 'package:flutter/material.dart';
import 'coming_screen.dart';
import 'contents_list_screen.dart';
import 'home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        //primarySwatch: Colors.grey,
        //primaryColor: Colors.grey,
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: AppBarTheme(color: Colors.black),
        textTheme: TextTheme(
          // 1
          //bodyLarge: TextStyle(color: Colors.red),
          bodyMedium: TextStyle(color: Colors.grey),
          //bodySmall: TextStyle(color: Colors.green),
        ),
      ),
      home: SplashScreen(),
      //Netflix(),
    );
  }
}

class Netflix extends StatefulWidget {
  const Netflix({Key? key}) : super(key: key);

  @override
  State<Netflix> createState() => _NetflixState();
}

class _NetflixState extends State<Netflix> {
  int _selectedIndex = 0;
  List pages = [
    HomeScreen(),
    ComingScreen(),
    ContentsListScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        backgroundColor: Colors.black,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey, //Color(0xFF6c6c6c),
        unselectedFontSize: 14.0,
        selectedFontSize: 16.0,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '홈',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.movie_creation_outlined),
            label: '공개 예정',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.arrow_circle_down),
            label: '저장한 콘텐츠 목록',
          )
        ],
      ),
    );
  }
}

// 넷플릭스 화면(첫화면)
class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => Netflix()));
      // pushReplacement : 다시 돌아오지 않게 지정 (스택에 남기지 않음)
    });
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Text(
          "NETFLIX",
          style: TextStyle(
            color: Colors.red,
            fontSize: 30,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );

  }
}
